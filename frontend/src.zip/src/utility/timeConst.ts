export const SecondOfMs = 1000;
export const MinuteOfMs = SecondOfMs * 60;
export const HourOfMs = MinuteOfMs * 60;
export const DayOfMs = HourOfMs * 24;
export const WeekOfMs = DayOfMs * 7;
export const MonthOfMs = DayOfMs * 30;
export const YearOfMs = DayOfMs * 365;