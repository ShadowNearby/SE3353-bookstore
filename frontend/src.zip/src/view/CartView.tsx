import React from "react";
import { Cart } from "../compoents/cart/Cart";

export const CartView = () => {
  return <Cart />;
};
