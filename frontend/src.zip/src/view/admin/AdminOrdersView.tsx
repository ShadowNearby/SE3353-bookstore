import { AdminOrders } from "../../compoents/admin/AdminOrders";

export const AdminOrdersView = () => {
  return <AdminOrders />;
};