import { AdminUsers } from "../../compoents/admin/AdminUsers";

export const AdminUsersView = () => {
  return <AdminUsers />;
};