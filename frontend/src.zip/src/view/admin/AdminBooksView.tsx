import { AdminBooks } from "../../compoents/admin/AdminBooks";

export const AdminBooksView = () => {
  return <AdminBooks />;
};