import { Order } from "../compoents/order/Order";

export const OrderView = () => {
  return <Order />;
};
